import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainnotification',
  templateUrl: './mainnotification.page.html',
  styleUrls: ['./mainnotification.page.scss'],
})
export class MainnotificationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
