import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-makemoney',
  templateUrl: './makemoney.page.html',
  styleUrls: ['./makemoney.page.scss'],
})
export class MakemoneyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
